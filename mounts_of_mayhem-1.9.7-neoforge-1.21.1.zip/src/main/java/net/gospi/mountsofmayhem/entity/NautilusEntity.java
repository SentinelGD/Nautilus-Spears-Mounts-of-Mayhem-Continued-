package net.gospi.mountsofmayhem.entity;

import net.neoforged.neoforge.fluids.FluidType;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.EventHooks;
import net.neoforged.neoforge.common.NeoForgeMod;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.level.pathfinder.PathType;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.animal.Pufferfish;
import net.minecraft.world.entity.ai.navigation.WaterBoundPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.TryFindWaterGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.RandomSwimmingGoal;
import net.minecraft.world.entity.ai.goal.FollowParentGoal;
import net.minecraft.world.entity.ai.goal.BreedGoal;
import net.minecraft.world.entity.ai.control.MoveControl;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.AnimationState;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.util.Mth;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.registries.BuiltInRegistries;

import net.gospi.mountsofmayhem.procedures.NautilusTestPriObnovlieniiTikaSushchnostiProcedure;
import net.gospi.mountsofmayhem.procedures.NautilusTestPriGibieliSushchnostiProcedure;
import net.gospi.mountsofmayhem.procedures.NautilusPriNachalnomPrizyvieSushchnostiProcedure;
import net.gospi.mountsofmayhem.init.MountsOfMayhemModEntities;

import javax.annotation.Nullable;

public class NautilusEntity extends TamableAnimal {
	public final AnimationState animationState0 = new AnimationState();
	private Vec3 externalMotion = Vec3.ZERO;

	public NautilusEntity(EntityType<NautilusEntity> type, Level world) {
		super(type, world);
		xpReward = 3;
		setNoAi(false);
		this.setPathfindingMalus(PathType.WATER, 0);
		this.moveControl = new MoveControl(this) {
			@Override
			public void tick() {
				if (NautilusEntity.this.isInWater())
					NautilusEntity.this.setDeltaMovement(NautilusEntity.this.getDeltaMovement().add(0, 0.005, 0));
				if (this.operation == MoveControl.Operation.MOVE_TO && !NautilusEntity.this.getNavigation().isDone()) {
					double dx = this.wantedX - NautilusEntity.this.getX();
					double dy = this.wantedY - NautilusEntity.this.getY();
					double dz = this.wantedZ - NautilusEntity.this.getZ();
					float f = (float) (Mth.atan2(dz, dx) * (double) (180 / Math.PI)) - 90;
					float f1 = (float) (this.speedModifier * NautilusEntity.this.getAttribute(Attributes.MOVEMENT_SPEED).getValue());
					NautilusEntity.this.setYRot(this.rotlerp(NautilusEntity.this.getYRot(), f, 10));
					NautilusEntity.this.yBodyRot = NautilusEntity.this.getYRot();
					NautilusEntity.this.yHeadRot = NautilusEntity.this.getYRot();
					if (NautilusEntity.this.isInWater()) {
						NautilusEntity.this.setSpeed((float) NautilusEntity.this.getAttribute(Attributes.MOVEMENT_SPEED).getValue());
						float f2 = -(float) (Mth.atan2(dy, (float) Math.sqrt(dx * dx + dz * dz)) * (180 / Math.PI));
						f2 = Mth.clamp(Mth.wrapDegrees(f2), -85, 85);
						NautilusEntity.this.setXRot(this.rotlerp(NautilusEntity.this.getXRot(), f2, 5));
						float f3 = Mth.cos(NautilusEntity.this.getXRot() * (float) (Math.PI / 180.0));
						NautilusEntity.this.setZza(f3 * f1);
						NautilusEntity.this.setYya((float) (f1 * dy));
					} else {
						NautilusEntity.this.setSpeed(f1 * 0.05F);
					}
				} else {
					NautilusEntity.this.setSpeed(0);
					NautilusEntity.this.setYya(0);
					NautilusEntity.this.setZza(0);
				}
			}
		};
	}

	@Override
	protected PathNavigation createNavigation(Level world) {
		return new WaterBoundPathNavigation(this, world);
	}

	@Override
	protected void registerGoals() {
		super.registerGoals();
		this.goalSelector.addGoal(1, new RandomSwimmingGoal(this, 1, 40));
		this.targetSelector.addGoal(2, new HurtByTargetGoal(this).setAlertOthers());
		this.targetSelector.addGoal(3, new NearestAttackableTargetGoal(this, Pufferfish.class, false, true));
		this.goalSelector.addGoal(4, new FollowParentGoal(this, 0.8));
		this.goalSelector.addGoal(5, new BreedGoal(this, 1));
		this.goalSelector.addGoal(6, new TryFindWaterGoal(this));
		this.goalSelector.addGoal(7, new TemptGoal(this, 1, Ingredient.of(Items.PUFFERFISH), false));
	}

	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}

	@Override
	public SoundEvent getAmbientSound() {
		return BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("mounts_of_mayhem:entity.nautilus.ambient"));
	}

	@Override
	public SoundEvent getHurtSound(DamageSource ds) {
		return BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("mounts_of_mayhem:entity.nautilus.hurt"));
	}

	@Override
	public SoundEvent getDeathSound() {
		return BuiltInRegistries.SOUND_EVENT.get(ResourceLocation.parse("mounts_of_mayhem:entity.nautilus.death"));
	}

	@Override
	public void die(DamageSource source) {
		super.die(source);
		NautilusTestPriGibieliSushchnostiProcedure.execute(this.level(), this.getX(), this.getY(), this.getZ());
	}

	@Override
	public SpawnGroupData finalizeSpawn(ServerLevelAccessor world, DifficultyInstance difficulty, MobSpawnType reason, @Nullable SpawnGroupData livingdata) {
		SpawnGroupData retval = super.finalizeSpawn(world, difficulty, reason, livingdata);
		NautilusPriNachalnomPrizyvieSushchnostiProcedure.execute(this);
		return retval;
	}

	@Override
	public InteractionResult mobInteract(Player sourceentity, InteractionHand hand) {
		ItemStack itemstack = sourceentity.getItemInHand(hand);
		InteractionResult retval = InteractionResult.sidedSuccess(this.level().isClientSide());
		Item item = itemstack.getItem();
		
		if (itemstack.getItem() instanceof SpawnEggItem) {
			retval = super.mobInteract(sourceentity, hand);
		} else if (this.level().isClientSide()) {
			retval = (this.isTame() && this.isOwnedBy(sourceentity) || this.isFood(itemstack)) ? InteractionResult.sidedSuccess(this.level().isClientSide()) : InteractionResult.PASS;
		} else {
			if (this.isTame()) {
				if (this.isOwnedBy(sourceentity)) {
					if (this.isFood(itemstack) && this.getHealth() < this.getMaxHealth()) {
						this.usePlayerItem(sourceentity, hand, itemstack);
						FoodProperties foodproperties = itemstack.getFoodProperties(this);
						float nutrition = foodproperties != null ? (float) foodproperties.nutrition() : 1;
						this.heal(nutrition);
						retval = InteractionResult.sidedSuccess(this.level().isClientSide());
					} else if (this.isFood(itemstack) && this.getHealth() < this.getMaxHealth()) {
						this.usePlayerItem(sourceentity, hand, itemstack);
						this.heal(4);
						retval = InteractionResult.sidedSuccess(this.level().isClientSide());
					} else {
						retval = super.mobInteract(sourceentity, hand);
					}
				}
			} else if (this.isFood(itemstack)) {
				this.usePlayerItem(sourceentity, hand, itemstack);
				if (this.random.nextInt(3) == 0 && !EventHooks.onAnimalTame(this, sourceentity)) {
					this.tame(sourceentity);
					this.level().broadcastEntityEvent(this, (byte) 7);
				} else {
					this.level().broadcastEntityEvent(this, (byte) 6);
				}
				this.setPersistenceRequired();
				retval = InteractionResult.sidedSuccess(this.level().isClientSide());
			} else {
				retval = super.mobInteract(sourceentity, hand);
				if (retval == InteractionResult.SUCCESS || retval == InteractionResult.CONSUME)
					this.setPersistenceRequired();
			}
		}
		
		return retval;
	}

	@Override
	public void tick() {
		super.tick();
		
		// Сильная плавучесть - наутилус не должен тонуть
		if (this.isInWater()) {
			Vec3 motion = this.getDeltaMovement();
			// Добавляем сильную плавучесть
			if (motion.y < 0) {
				this.setDeltaMovement(motion.x, motion.y * 0.3, motion.z);
			}
		}
		
		// Применяем внешнее движение если оно есть
		if (!this.externalMotion.equals(Vec3.ZERO)) {
			this.setDeltaMovement(this.getDeltaMovement().add(this.externalMotion));
			this.externalMotion = Vec3.ZERO;
		}
		
		if (this.level().isClientSide()) {
			this.animationState0.animateWhen(true, this.tickCount);
		}
	}

	// Метод для добавления внешнего движения из процедур
	public void addExternalMotion(Vec3 motion) {
		this.externalMotion = this.externalMotion.add(motion);
	}

	@Override
	public void baseTick() {
		super.baseTick();
		NautilusTestPriObnovlieniiTikaSushchnostiProcedure.execute(this);
	}

	@Override
	public AgeableMob getBreedOffspring(ServerLevel serverWorld, AgeableMob ageable) {
		NautilusEntity retval = MountsOfMayhemModEntities.NAUTILUS.get().create(serverWorld);
		retval.finalizeSpawn(serverWorld, serverWorld.getCurrentDifficultyAt(retval.blockPosition()), MobSpawnType.BREEDING, null);
		return retval;
	}

	@Override
	public boolean isFood(ItemStack stack) {
		return Ingredient.of(new ItemStack(Items.PUFFERFISH), new ItemStack(Items.PUFFERFISH_BUCKET)).test(stack);
	}

	@Override
	public boolean checkSpawnObstruction(LevelReader world) {
		return world.isUnobstructed(this);
	}

	@Override
	public boolean canDrownInFluidType(FluidType type) {
		return false;
	}

	@Override
	public boolean isPushedByFluid() {
		return false;
	}

	@Override
	public void travel(Vec3 dir) {
		if (this.isVehicle()) {
			LivingEntity passenger = this.getControllingPassenger();
			if (passenger != null) {
				this.setYRot(passenger.getYRot());
				this.yRotO = this.getYRot();
				this.setXRot(passenger.getXRot() * 0.5F);
				this.setRot(this.getYRot(), this.getXRot());
				this.yBodyRot = this.getYRot();
				this.yHeadRot = this.getYRot();
				
				float forward = passenger.zza;
				float strafe = passenger.xxa;
				
				// Управление в воде
				if (this.isInWater()) {
					// Базовая скорость
					float baseSpeed = (float) this.getAttributeValue(Attributes.MOVEMENT_SPEED) * 2.0f;
					
					// Получаем угол наклона головы игрока (от -90 до 90 градусов)
					float pitch = passenger.getXRot();
					float pitchRad = pitch * ((float) Math.PI / 180F);
					float yawRad = passenger.getYRot() * ((float) Math.PI / 180F);
					
					// Коэффициент вертикального наклона (0 = смотрим прямо, 1 = смотрим вверх/вниз)
					float verticalFactor = Math.abs(pitch) / 90.0f;
					
					// Горизонтальная скорость уменьшается при наклоне головы вверх/вниз
					float horizontalSpeed = baseSpeed * (1.0f - verticalFactor * 0.7f);
					float verticalSpeed = baseSpeed * verticalFactor * 1.5f;
					
					// Основное направление движения (вперед/назад)
					float moveX = -Mth.sin(yawRad);
					float moveZ = Mth.cos(yawRad);
					
					// Вертикальное движение
					float verticalDirection = -Mth.sin(pitchRad);
					
					// Комбинируем движение
					double desiredX = 0;
					double desiredY = 0;
					double desiredZ = 0;
					
					if (forward != 0) {
						// Горизонтальное движение с уменьшенной скоростью при наклоне
						desiredX += moveX * forward * horizontalSpeed;
						desiredZ += moveZ * forward * horizontalSpeed;
						// Вертикальное движение
						desiredY += verticalDirection * Math.abs(forward) * verticalSpeed;
					}
					
					// Боковое движение (ИСПРАВЛЕНО направление)
					if (strafe != 0) {
						// Правильное направление для бокового движения
						// A (strafe = -1) = влево, D (strafe = 1) = вправо
						float strafeX = -Mth.sin(yawRad - (float) Math.PI / 2); // ИСПРАВЛЕНО: минус вместо плюса
						float strafeZ = Mth.cos(yawRad - (float) Math.PI / 2);  // ИСПРАВЛЕНО: минус вместо плюса
						desiredX += strafeX * strafe * horizontalSpeed;
						desiredZ += strafeZ * strafe * horizontalSpeed;
					}
					
					// Прямое применение движения без плавности
					this.setDeltaMovement(desiredX, desiredY, desiredZ);
				}
				
				super.travel(new Vec3(strafe, 0, forward));
				this.tryCheckInsideBlocks();
				return;
			}
		}
		super.travel(dir);
	}
	
	@Nullable
	@Override
	public LivingEntity getControllingPassenger() {
		Entity passenger = this.getFirstPassenger();
		if (passenger instanceof LivingEntity living) {
			return living;
		}
		return null;
	}

	public static void init(RegisterSpawnPlacementsEvent event) {
		event.register(MountsOfMayhemModEntities.NAUTILUS.get(), SpawnPlacementTypes.IN_WATER, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
				(entityType, world, reason, pos, random) -> (world.getBlockState(pos).is(Blocks.WATER) && world.getBlockState(pos.above()).is(Blocks.WATER)), RegisterSpawnPlacementsEvent.Operation.REPLACE);
	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0.15);
		builder = builder.add(Attributes.MAX_HEALTH, 12);
		builder = builder.add(Attributes.ARMOR, 0);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 3);
		builder = builder.add(Attributes.FOLLOW_RANGE, 8);
		builder = builder.add(Attributes.STEP_HEIGHT, 0.6);
		builder = builder.add(Attributes.KNOCKBACK_RESISTANCE, 0.1);
		builder = builder.add(Attributes.ATTACK_KNOCKBACK, 0.6);
		builder = builder.add(NeoForgeMod.SWIM_SPEED, 1.5);
		return builder;
	}
}