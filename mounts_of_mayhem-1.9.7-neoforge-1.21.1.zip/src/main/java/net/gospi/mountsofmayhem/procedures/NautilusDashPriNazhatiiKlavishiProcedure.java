package net.gospi.mountsofmayhem.procedures;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.network.chat.Component;

import net.gospi.mountsofmayhem.entity.NautilusEntity;
import net.gospi.mountsofmayhem.MountsOfMayhemMod;

import java.util.Comparator;

public class NautilusDashPriNazhatiiKlavishiProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity.isPassenger()) {
			{
				final Vec3 _center = new Vec3(x, y, z);
				for (Entity entityiterator : world.getEntitiesOfClass(Entity.class, new AABB(_center, _center).inflate(3 / 2d), e -> true).stream().sorted(Comparator.comparingDouble(_entcnd -> _entcnd.distanceToSqr(_center))).toList()) {
					if (entityiterator instanceof NautilusEntity) {
						if (entityiterator.getPersistentData().getBoolean("dash") == false) {
							entityiterator.getPersistentData().putBoolean("dash", true);
							entityiterator.setDeltaMovement(new Vec3((Mth.nextInt(RandomSource.create(), 5, 8) * entity.getLookAngle().x), (Mth.nextInt(RandomSource.create(), 5, 8) * entity.getLookAngle().y),
									(Mth.nextInt(RandomSource.create(), 5, 8) * entity.getLookAngle().z)));
							MountsOfMayhemMod.queueServerWork(100, () -> {
								if (entity instanceof Player _player && !_player.level().isClientSide())
									_player.displayClientMessage(Component.literal((Component.translatable("nautilus.dash").getString())), true);
								entityiterator.getPersistentData().putBoolean("dash", false);
							});
						}
					}
				}
			}
		}
	}
}